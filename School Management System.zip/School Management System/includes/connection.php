<?php
$connection = mysqli_connect("localhost","root","");
$db = mysqli_select_db($connection,"school_db");
?>
